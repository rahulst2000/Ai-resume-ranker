import os
import logging
import tempfile
import pandas as pd
from flask import Flask, render_template, request, redirect, url_for, flash, session, send_file, jsonify
from werkzeug.utils import secure_filename
from werkzeug.middleware.proxy_fix import ProxyFix
from resume_ranker import extract_text_from_pdf, preprocess_text, rank_resumes, filter_resumes_by_rank, generate_ats_friendly_resume, create_resume_template

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev_secret_key")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

# Configure upload settings
ALLOWED_EXTENSIONS = {'pdf'}
UPLOAD_FOLDER = tempfile.gettempdir()
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max size

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_files():
    # Check if job description is provided
    job_description = request.form.get('job_description', '').strip()
    if not job_description:
        flash('Please provide a job description', 'danger')
        return redirect(url_for('index'))
    
    # Check if files are uploaded
    if 'resumes' not in request.files:
        flash('No files uploaded', 'danger')
        return redirect(url_for('index'))
    
    files = request.files.getlist('resumes')
    
    if not files or not files[0].filename:
        flash('No files selected', 'danger')
        return redirect(url_for('index'))
    
    # Process uploaded resumes
    resume_data = []
    
    for file in files:
        if file and file.filename and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)
            
            try:
                # Extract text from PDF
                extracted_text = extract_text_from_pdf(filepath)
                
                if not extracted_text:
                    flash(f'Could not extract text from {filename}', 'warning')
                    continue
                
                # Add to resume data list
                resume_data.append({
                    'filename': filename,
                    'text': extracted_text,
                    'preprocessed_text': preprocess_text(extracted_text)
                })
                
            except Exception as e:
                logging.error(f"Error processing {filename}: {str(e)}")
                flash(f'Error processing {filename}: {str(e)}', 'danger')
            finally:
                # Clean up the temporary file
                if os.path.exists(filepath):
                    os.remove(filepath)
    
    if not resume_data:
        flash('No valid resumes were uploaded', 'danger')
        return redirect(url_for('index'))
    
    # Preprocess job description
    preprocessed_job_desc = preprocess_text(job_description)
    
    # Rank resumes
    ranked_resumes = rank_resumes(resume_data, preprocessed_job_desc)
    
    # Store in session for results page
    session['ranked_resumes'] = ranked_resumes
    session['job_description'] = job_description
    
    return redirect(url_for('results'))

@app.route('/results')
def results():
    if 'ranked_resumes' not in session or 'job_description' not in session:
        flash('No analysis results available', 'warning')
        return redirect(url_for('index'))
    
    ranked_resumes = session['ranked_resumes']
    job_description = session['job_description']
    
    # Default to showing all resumes
    min_rank = request.args.get('min_rank', 1, type=int)
    max_rank = request.args.get('max_rank', None, type=int)
    
    # Filter resumes by rank if requested
    if min_rank > 1 or max_rank:
        filtered_resumes = filter_resumes_by_rank(ranked_resumes, min_rank, max_rank)
    else:
        filtered_resumes = ranked_resumes
    
    return render_template('results.html', 
                           resumes=filtered_resumes,
                           all_resumes=ranked_resumes,
                           job_description=job_description,
                           min_rank=min_rank,
                           max_rank=max_rank)

@app.route('/download_report')
def download_report():
    if 'ranked_resumes' not in session:
        flash('No analysis results available', 'warning')
        return redirect(url_for('index'))
    
    ranked_resumes = session['ranked_resumes']
    
    # Get filter parameters if they exist
    min_rank = request.args.get('min_rank', 1, type=int)
    max_rank = request.args.get('max_rank', None, type=int)
    
    # Filter by rank if requested
    if min_rank > 1 or max_rank:
        report_resumes = filter_resumes_by_rank(ranked_resumes, min_rank, max_rank)
    else:
        report_resumes = ranked_resumes
    
    # Create a dataframe and save as CSV
    df = pd.DataFrame(report_resumes)
    
    # Create temporary CSV file
    temp_csv = os.path.join(app.config['UPLOAD_FOLDER'], 'resume_ranking_report.csv')
    df.to_csv(temp_csv, index=False)
    
    # Send file to client
    return send_file(
        temp_csv,
        mimetype='text/csv',
        as_attachment=True,
        download_name='resume_ranking_report.csv'
    )

@app.route('/ats_resume/<int:resume_index>')
def ats_resume(resume_index):
    if 'ranked_resumes' not in session or 'job_description' not in session:
        flash('No analysis results available', 'warning')
        return redirect(url_for('index'))
        
    ranked_resumes = session['ranked_resumes']
    job_description = session['job_description']
    
    # Verify resume index is valid
    if resume_index < 0 or resume_index >= len(ranked_resumes):
        flash('Invalid resume selection', 'danger')
        return redirect(url_for('results'))
    
    # Get the selected resume
    resume = ranked_resumes[resume_index]
    
    # Generate ATS-friendly version
    ats_friendly_content = generate_ats_friendly_resume(
        resume['text'], 
        job_description, 
        resume['key_skills']
    )
    
    return render_template('ats_resume.html', 
        resume=resume, 
        ats_content=ats_friendly_content,
        job_description=job_description
    )

@app.route('/resume_template')
def resume_template():
    """Display a blank resume template that users can customize"""
    template_content = create_resume_template()
    
    return render_template('resume_template.html', 
        template_content=template_content
    )

@app.route('/filter_resumes', methods=['POST'])
def filter_resumes():
    """Handle resume filtering form submission"""
    if 'ranked_resumes' not in session:
        flash('No analysis results available', 'warning')
        return redirect(url_for('index'))
    
    # Get filter parameters
    min_rank = request.form.get('min_rank', 1, type=int)
    max_rank = request.form.get('max_rank', None)
    
    # Convert empty string to None for max_rank
    if max_rank == '':
        max_rank = None
    elif max_rank is not None:
        max_rank = int(max_rank)
    
    # Redirect to results with filter params
    return redirect(url_for('results', min_rank=min_rank, max_rank=max_rank))

@app.route('/clear_session')
def clear_session():
    session.clear()
    return redirect(url_for('index'))

@app.errorhandler(413)
def too_large(e):
    flash('The file is too large. Maximum size is 16MB.', 'danger')
    return redirect(url_for('index'))

@app.errorhandler(500)
def server_error(e):
    flash('An internal server error occurred. Please try again.', 'danger')
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
