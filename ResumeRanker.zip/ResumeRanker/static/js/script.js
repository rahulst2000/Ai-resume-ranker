// Resume Ranker Application JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // File input handling
    const fileInput = document.getElementById('resumes');
    const fileList = document.getElementById('fileList');
    const selectedFiles = document.getElementById('selectedFiles');
    const uploadForm = document.getElementById('uploadForm');
    const submitBtn = document.getElementById('submitBtn');
    const loadingSpinner = document.getElementById('loadingSpinner');
    const buttonText = document.getElementById('buttonText');

    // Handle file selection
    if (fileInput) {
        fileInput.addEventListener('change', function() {
            updateFileList();
        });
    }

    // Handle form submission
    if (uploadForm) {
        uploadForm.addEventListener('submit', function() {
            // Show loading state
            if (loadingSpinner && buttonText) {
                loadingSpinner.classList.remove('d-none');
                buttonText.textContent = 'Processing...';
                submitBtn.disabled = true;
            }
        });
    }

    // Update the list of selected files
    function updateFileList() {
        if (!fileInput || !fileList || !selectedFiles) return;

        if (fileInput.files.length > 0) {
            fileList.classList.remove('d-none');
            selectedFiles.innerHTML = '';

            Array.from(fileInput.files).forEach(function(file, index) {
                const fileSize = formatFileSize(file.size);
                const listItem = document.createElement('li');
                listItem.className = 'list-group-item d-flex justify-content-between align-items-center';
                
                listItem.innerHTML = `
                    <div>
                        <i class="bi bi-file-earmark-pdf text-danger"></i>
                        <span>${file.name}</span>
                        <small class="text-muted ms-2">${fileSize}</small>
                    </div>
                    <span class="badge bg-primary rounded-pill">${index + 1}</span>
                `;
                
                selectedFiles.appendChild(listItem);
            });
        } else {
            fileList.classList.add('d-none');
            selectedFiles.innerHTML = '';
        }
    }

    // Format file size to readable format
    function formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    // Auto-dismiss alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(function(alert) {
        setTimeout(function() {
            const closeButton = alert.querySelector('.btn-close');
            if (closeButton) {
                closeButton.click();
            }
        }, 5000);
    });
});
